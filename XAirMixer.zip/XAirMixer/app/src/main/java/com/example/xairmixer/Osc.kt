package com.example.xairmixer

import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer

/** Encoder/decoder OSC minimal (int, float, string, blob). */
object Osc {
    data class Msg(val addr: String, val args: List<Any>)

    private fun pad(s: String): ByteArray {
        val b = s.toByteArray(Charsets.US_ASCII)
        return b.copyOf((b.size / 4 + 1) * 4)
    }

    fun encode(addr: String, vararg args: Any): ByteArray {
        val out = ByteArrayOutputStream()
        out.write(pad(addr))
        val tags = StringBuilder(",")
        args.forEach {
            tags.append(
                when (it) {
                    is Float -> 'f'
                    is Int -> 'i'
                    is String -> 's'
                    else -> error("Tipe OSC tidak didukung")
                }
            )
        }
        out.write(pad(tags.toString()))
        args.forEach {
            when (it) {
                is Float -> out.write(ByteBuffer.allocate(4).putFloat(it).array())
                is Int -> out.write(ByteBuffer.allocate(4).putInt(it).array())
                is String -> out.write(pad(it))
            }
        }
        return out.toByteArray()
    }

    fun decode(data: ByteArray, len: Int): Msg? {
        var p = 0
        fun readStr(): String {
            val start = p
            while (p < len && data[p] != 0.toByte()) p++
            val r = String(data, start, p - start, Charsets.US_ASCII)
            p = (p / 4 + 1) * 4
            return r
        }
        val addr = readStr()
        if (!addr.startsWith("/")) return null
        val tags = if (p < len) readStr() else ","
        val args = mutableListOf<Any>()
        for (t in tags.drop(1)) {
            if (p > len) break
            when (t) {
                'f' -> { args += ByteBuffer.wrap(data, p, 4).float; p += 4 }
                'i' -> { args += ByteBuffer.wrap(data, p, 4).int; p += 4 }
                's' -> args += readStr()
                'b' -> { val n = ByteBuffer.wrap(data, p, 4).int; p += 4 + (n + 3) / 4 * 4 }
                else -> return Msg(addr, args)
            }
        }
        return Msg(addr, args)
    }
}
