package com.example.xairmixer

import kotlinx.coroutines.*
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.*
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.SocketTimeoutException

const val XAIR_PORT = 10024

val CHANNEL_KEYS = (1..16).map { "ch/%02d".format(it) }
const val MAIN_KEY = "lr"

data class Strip(val name: String, val fader: Float = 0f, val on: Boolean = true)

data class MixerState(
    val connected: Boolean = false,
    val status: String = "Belum terhubung",
    val strips: Map<String, Strip> =
        CHANNEL_KEYS.mapIndexed { i, k -> k to Strip("CH ${i + 1}") }.toMap() +
            (MAIN_KEY to Strip("MAIN")),
)

class XAirClient(private val scope: CoroutineScope) {
    private val _state = MutableStateFlow(MixerState())
    val state: StateFlow<MixerState> = _state

    private var socket: DatagramSocket? = null
    private var target: InetAddress? = null
    private var session: Job? = null
    private var outbox = Channel<ByteArray>(Channel.UNLIMITED)

    private val re = Regex("^/(ch/\\d\\d|lr)/(mix/fader|mix/on|config/name)$")

    fun connect(ip: String) {
        disconnect()
        _state.update { it.copy(status = "Menghubungkan...", connected = false) }
        outbox = Channel(Channel.UNLIMITED)
        session = scope.launch(Dispatchers.IO) {
            try {
                val addr = InetAddress.getByName(ip.trim())
                val s = DatagramSocket()
                socket = s; target = addr
                val box = outbox

                launch { // pengirim berurutan
                    for (data in box) {
                        try { s.send(DatagramPacket(data, data.size, addr, XAIR_PORT)) } catch (_: Exception) {}
                    }
                }
                launch { receiveLoop(s) }
                launch { // keepalive /xremote < 10 detik
                    while (isActive) { box.trySend(Osc.encode("/xremote")); delay(8000) }
                }
                repeat(5) {
                    if (!_state.value.connected) { queryAll(); delay(1200) }
                }
                if (!_state.value.connected) {
                    _state.update { it.copy(status = "Tidak ada respons dari $ip") }
                }
            } catch (e: Exception) {
                _state.update { it.copy(status = "Gagal: ${e.message}") }
            }
        }
    }

    fun disconnect() {
        session?.cancel(); session = null
        outbox.close()
        socket?.close(); socket = null
        _state.update { it.copy(connected = false, status = "Belum terhubung") }
    }

    private fun queryAll() {
        outbox.trySend(Osc.encode("/xremote"))
        (CHANNEL_KEYS + MAIN_KEY).forEach { k ->
            outbox.trySend(Osc.encode("/$k/mix/fader"))
            outbox.trySend(Osc.encode("/$k/mix/on"))
            if (k != MAIN_KEY) outbox.trySend(Osc.encode("/$k/config/name"))
        }
    }

    private fun receiveLoop(s: DatagramSocket) {
        val buf = ByteArray(2048)
        while (!s.isClosed) {
            val p = DatagramPacket(buf, buf.size)
            try { s.receive(p) } catch (_: Exception) { break }
            Osc.decode(p.data, p.length)?.let(::handle)
        }
    }

    private fun handle(msg: Osc.Msg) {
        val m = re.matchEntire(msg.addr)
        _state.update { st ->
            var next = if (!st.connected) st.copy(connected = true, status = "Terhubung") else st
            if (m != null) {
                val key = m.groupValues[1]
                val old = next.strips[key]
                val arg = msg.args.firstOrNull()
                if (old != null && arg != null) {
                    val upd = when (m.groupValues[2]) {
                        "mix/fader" -> (arg as? Float)?.let { old.copy(fader = it) }
                        "mix/on" -> (arg as? Int)?.let { old.copy(on = it == 1) }
                        else -> (arg as? String)?.let { old.copy(name = it.ifBlank { defaultName(key) }) }
                    }
                    if (upd != null) next = next.copy(strips = next.strips + (key to upd))
                }
            }
            next
        }
    }

    private fun defaultName(key: String) =
        if (key == MAIN_KEY) "MAIN" else "CH ${key.takeLast(2).toInt()}"

    fun setFader(key: String, v: Float) {
        val value = v.coerceIn(0f, 1f)
        _state.update { st -> st.strips[key]?.let { st.copy(strips = st.strips + (key to it.copy(fader = value))) } ?: st }
        outbox.trySend(Osc.encode("/$key/mix/fader", value))
    }

    fun setOn(key: String, on: Boolean) {
        _state.update { st -> st.strips[key]?.let { st.copy(strips = st.strips + (key to it.copy(on = on))) } ?: st }
        outbox.trySend(Osc.encode("/$key/mix/on", if (on) 1 else 0))
    }

    /** Broadcast /xinfo, kembalikan IP mixer pertama yang menjawab. */
    suspend fun discover(): String? = withContext(Dispatchers.IO) {
        DatagramSocket().use { s ->
            s.broadcast = true
            s.soTimeout = 2500
            val d = Osc.encode("/xinfo")
            s.send(DatagramPacket(d, d.size, InetAddress.getByName("255.255.255.255"), XAIR_PORT))
            try {
                val p = DatagramPacket(ByteArray(512), 512)
                s.receive(p)
                p.address.hostAddress
            } catch (_: SocketTimeoutException) { null }
        }
    }
}
