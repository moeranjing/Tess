package com.example.xairmixer

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class MixerViewModel : ViewModel() {
    private val client = XAirClient(viewModelScope)
    val state: StateFlow<MixerState> = client.state

    private val _ip = MutableStateFlow("192.168.1.1")
    val ip: StateFlow<String> = _ip
    fun setIp(v: String) { _ip.value = v }

    fun connect() = client.connect(_ip.value)
    fun disconnect() = client.disconnect()
    fun discover() = viewModelScope.launch {
        client.discover()?.let { _ip.value = it; client.connect(it) }
    }
    fun setFader(key: String, v: Float) = client.setFader(key, v)
    fun setOn(key: String, on: Boolean) = client.setOn(key, on)

    override fun onCleared() { client.disconnect() }
}
