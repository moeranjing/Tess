package com.example.xairmixer.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.xairmixer.CHANNEL_KEYS
import com.example.xairmixer.MAIN_KEY
import com.example.xairmixer.MixerViewModel
import com.example.xairmixer.Strip

private val MainColor = Color(0xFFFFD600)
private fun stripColor(i: Int) = Color.hsv(i * 360f / 16f, 0.7f, 1f)

/** Konversi posisi fader X Air (0..1) ke dB. */
private fun faderToDb(f: Float): String {
    if (f < 0.001f) return "-∞"
    val db = when {
        f >= 0.5f -> f * 40f - 30f
        f >= 0.25f -> f * 80f - 50f
        f >= 0.0625f -> f * 160f - 70f
        else -> f * 480f - 90f
    }
    return "%.1f".format(db)
}

@Composable
fun MixerScreen(vm: MixerViewModel = viewModel()) {
    val st by vm.state.collectAsStateWithLifecycle()
    val ip by vm.ip.collectAsStateWithLifecycle()

    Column(
        Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0xFF1B0036), Color(0xFF001A33))))
            .statusBarsPadding()
            .padding(8.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(
                value = ip, onValueChange = vm::setIp, singleLine = true,
                label = { Text("IP XR18") }, modifier = Modifier.width(170.dp),
            )
            Button(onClick = { vm.connect() }, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00C853))) { Text("Hubungkan") }
            Button(onClick = { vm.discover() }, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2979FF))) { Text("Cari") }
            if (st.connected) {
                Button(onClick = { vm.disconnect() }, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF1744))) { Text("Putus") }
            }
            Box(Modifier.size(12.dp).clip(CircleShape).background(if (st.connected) Color(0xFF00E676) else Color(0xFFFF5252)))
            Text(st.status, color = Color.White, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Spacer(Modifier.height(8.dp))
        Row(Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            LazyRow(Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                itemsIndexed(CHANNEL_KEYS) { i, key ->
                    st.strips[key]?.let { s ->
                        StripView(s, stripColor(i), { vm.setFader(key, it) }, { vm.setOn(key, it) })
                    }
                }
            }
            st.strips[MAIN_KEY]?.let { s ->
                StripView(s, MainColor, { vm.setFader(MAIN_KEY, it) }, { vm.setOn(MAIN_KEY, it) })
            }
        }
    }
}

@Composable
private fun StripView(strip: Strip, color: Color, onFader: (Float) -> Unit, onOn: (Boolean) -> Unit) {
    val muted = !strip.on
    Column(
        Modifier
            .width(78.dp)
            .fillMaxHeight()
            .clip(RoundedCornerShape(16.dp))
            .background(color.copy(alpha = 0.12f))
            .border(BorderStroke(1.5.dp, color.copy(alpha = 0.7f)), RoundedCornerShape(16.dp))
            .padding(6.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(
            strip.name, color = color, fontWeight = FontWeight.Bold, fontSize = 13.sp,
            maxLines = 1, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center,
        )
        Fader(
            value = strip.fader, color = if (muted) color.copy(alpha = 0.35f) else color, onChange = onFader,
            modifier = Modifier.weight(1f).fillMaxWidth(),
        )
        Text(faderToDb(strip.fader), color = Color.White, fontSize = 12.sp)
        Spacer(Modifier.height(4.dp))
        Box(
            Modifier
                .fillMaxWidth()
                .height(36.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(if (muted) Color(0xFFFF1744) else color.copy(alpha = 0.25f))
                .clickable { onOn(!strip.on) },
            contentAlignment = Alignment.Center,
        ) {
            Text("MUTE", color = if (muted) Color.White else color, fontWeight = FontWeight.Bold, fontSize = 12.sp)
        }
    }
}

@Composable
private fun Fader(value: Float, color: Color, onChange: (Float) -> Unit, modifier: Modifier = Modifier) {
    val cb by rememberUpdatedState(onChange)
    Canvas(
        modifier
            .pointerInput(Unit) {
                val pad = 22.dp.toPx()
                fun toValue(y: Float) = (1f - (y - pad) / (size.height - 2 * pad)).coerceIn(0f, 1f)
                detectVerticalDragGestures(
                    onDragStart = { cb(toValue(it.y)) },
                    onVerticalDrag = { change, _ -> change.consume(); cb(toValue(change.position.y)) },
                )
            }
            .pointerInput(Unit) {
                val pad = 22.dp.toPx()
                detectTapGestures { cb((1f - (it.y - pad) / (size.height - 2 * pad)).coerceIn(0f, 1f)) }
            }
    ) {
        val pad = 22.dp.toPx()
        val trackW = size.width * 0.14f
        val cx = size.width / 2f
        val ty = pad + (size.height - 2 * pad) * (1f - value)
        drawRoundRect(Color(0x33FFFFFF), Offset(cx - trackW / 2, pad), Size(trackW, size.height - 2 * pad), CornerRadius(trackW / 2))
        drawRoundRect(
            Brush.verticalGradient(listOf(color, color.copy(alpha = 0.35f)), startY = ty, endY = size.height - pad),
            Offset(cx - trackW / 2, ty), Size(trackW, size.height - pad - ty), CornerRadius(trackW / 2),
        )
        val tw = size.width * 0.85f
        val th = 40.dp.toPx()
        drawRoundRect(color, Offset(cx - tw / 2, ty - th / 2), Size(tw, th), CornerRadius(10.dp.toPx()))
        drawRoundRect(Color(0xCC000000), Offset(cx - tw / 2 + 8.dp.toPx(), ty - 1.5.dp.toPx()), Size(tw - 16.dp.toPx(), 3.dp.toPx()), CornerRadius(2.dp.toPx()))
    }
}
