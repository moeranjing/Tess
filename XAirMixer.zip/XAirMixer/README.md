# XAir Mixer (Behringer XR18)

1. Buka folder ini di Android Studio (Koala/Ladybug atau lebih baru), tunggu Gradle sync.
2. Hubungkan HP ke WiFi XR18 (atau router yang sama). Matikan data seluler jika koneksi tidak terdeteksi.
3. Jalankan app, tekan "Cari" atau isi IP (default AP XR18: 192.168.1.1) lalu "Hubungkan".

Protokol: OSC/UDP port 10024, keepalive /xremote tiap 8 detik.
